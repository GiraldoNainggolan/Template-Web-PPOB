// Contoh: Validasi form pembelian pulsa
document.addEventListener("DOMContentLoaded", function () {
    const buyButtons = document.querySelectorAll("button");
    buyButtons.forEach((button) => {
      button.addEventListener("click", function () {
        alert("Fitur ini sedang dalam pengembangan!");
      });
    });
  });